package com.example.storyapp.ui.main

import android.app.Application
import android.util.Log
import androidx.lifecycle.*
import com.example.storyapp.data.remote.ApiConfig
import com.example.storyapp.data.remote.story.GetStoriesResponse
import com.example.storyapp.data.remote.story.StoryModel
import com.example.storyapp.preference.UserPreference
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val context = getApplication<Application>().applicationContext
    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    private val _error = MutableLiveData<Boolean>()
    val error: LiveData<Boolean> = _error

    private val _story = MutableLiveData<ArrayList<StoryModel>>()
    val story: LiveData<ArrayList<StoryModel>> = _story


    companion object {
        private const val TAG = "MainViewModel"
    }

    init {
        getAllStories()
    }


    fun getAllStories() {
        _isLoading.value = true
        _error.value = false
        val token = UserPreference(context).getUser().token
        val client = token?.let { tkn ->
            ApiConfig.getApiService().getALlStories(token = "Bearer $tkn", page = 1, size = 75)
        }
        client?.enqueue(object : Callback<GetStoriesResponse> {
            override fun onResponse(
                call: Call<GetStoriesResponse>,
                response: Response<GetStoriesResponse>
            ) {
                if (response.isSuccessful && response.body()?.error == false) {
                    _story.value = response.body()?.listStory
                    _isLoading.value = false
                    _error.value = false
                } else {
                    Log.e(TAG, "\"onFailure: ${response.message()}\"")
                }
            }

            override fun onFailure(call: Call<GetStoriesResponse>, t: Throwable) {
                _isLoading.value = false
                _error.value = true
                Log.e(TAG, "onFailure: ${t.message}")
            }

        })

    }

    fun logout() {
        viewModelScope.launch {
            UserPreference(context).logout()
        }
    }

}