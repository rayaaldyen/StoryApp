package com.example.storyapp.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.storyapp.data.remote.story.StoryModel
import com.example.storyapp.databinding.ItemListBinding
import com.example.storyapp.utils.withDateFormat

class StoriesAdapter(private val storyList: ArrayList<StoryModel>) :
    RecyclerView.Adapter<StoriesAdapter.ListViewHolder>() {

    private lateinit var onItemClickCallback: OnItemClickCallback

    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback
    }


    class ListViewHolder(var binding: ItemListBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListViewHolder {
        val view = ItemListBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ListViewHolder(view)
    }

    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {
        val stories = storyList[position]

        holder.binding.apply {
            Glide.with(holder.itemView.context)
                .load(stories.photoUrl)
                .into(storyPhoto)
            tvUsersName.text = stories.name
            tvDate.text = stories.createdAt.withDateFormat()
            tvDesc.text = stories.description
        }
        holder.itemView.setOnClickListener {
            onItemClickCallback.onItemClicked(stories)
        }


    }

    override fun getItemCount(): Int = storyList.size

    interface OnItemClickCallback {
        fun onItemClicked(story: StoryModel)
    }


}